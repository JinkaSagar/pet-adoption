import React from 'react';
import './Tagline.css';
const TagLine = ()=>{
    return(
        <div>
            <div class="tagline">
                <h1> Friendship is what Where beautiful Life begins</h1>
            </div>
        </div>
    )
}
export default TagLine;