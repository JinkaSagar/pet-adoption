import React from 'react';
import NavBar from "../NavBar"
class Navbar extends React.Component{
    render()
    {
        return(
          <NavBar />
        );
    }
}
export default Navbar;