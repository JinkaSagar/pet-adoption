module.exports = {
    mongoURI : "mongodb+srv://siddardha:siddardha@cluster0.hj6wi.mongodb.net/siddardha?retryWrites=true&w=majority",
    secretOrKey: "secret",
    refreshsecrettoken:"refreshsecrettoken"
}